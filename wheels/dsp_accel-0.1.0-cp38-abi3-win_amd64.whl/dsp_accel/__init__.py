from .dsp_accel import *

__doc__ = dsp_accel.__doc__
if hasattr(dsp_accel, "__all__"):
    __all__ = dsp_accel.__all__